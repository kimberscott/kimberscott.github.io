// Global variables (available in all functions)
var tic = new Date();
var eventArray = []; // appended to by addEvent to keep track of things that happen
var currentElement = -1; // State variable: which html element we're on
var htmlSequence = false;

// If sandbox is true, we skip all the calls to jswcam (to start/stop recording, etc.).
// 9.S93 students--keep to 'true' for testing.
var sandbox = true;

// The function 'main' must be defined and is called when the consent form is submitted 
// (or from sandbox.html)
function main(mainDivSelector, experiment) {
	
	console.log("Starting experiment: v1, ", experiment);
	$(mainDivSelector).attr('id', 'maindiv'); // so we can select it in css as #maindiv
	addEvent(  {'type': 'startLoading'});

	// Black out the screen until waitforassets returns	
	var box = bootbox.dialog(
		"Please wait while the experiment loads.", 
		[]); 
		
	if(sandbox) {
		// Just use a specific arbitrary condition number (0 through 63)
		condition = 61; 
		startExperiment(condition, box);
	} else {
		// Get the appropriate condition from the server by checking which ones we 
		// already have
	$.getJSON(
		'ex03counterbalance.php',
		{},
		function(jsonresp) {
			console.log(jsonresp);
			startExperiment(jsonresp.condition, box);
		}
	);
	}
	
// now wrapped so it can be called only after getting a condition via ajax
function startExperiment(condition, box) {

	// Counterbalancing condition sets
	// condition is a single number 0<=condition<64
	// condition = (iSideCondition * 16) + versionCondition
	// movies are named [storyLeft]_[storyRight]_s[WhichSoundIsOn]

	// the ith digit of the version condition in binary says whether the lower
	//  letter movie is on the right (e.g. B_E_sX is 0, E_B_sX is 1)
	var versionCondition = (condition % 16).toString(2);
	versionCondition = '0000'.substr(0, 4 - versionCondition.length) + versionCondition;
	console.log(versionCondition);
	
	// the ith character of the side condition says which face is talking during
	//  the ith test movie (e.g. B_E_sB is right/R)
	var sideConditions = ['LLRR', 'LRLR', 'LRRL', 'RLLR', 'RLRL', 'RRLL'];
	var iSideCondition   = Math.floor(condition / 16);
	var sides = sideConditions[iSideCondition];
	console.log(sides);

	var movieReference = [	['B_E_sB', 'E_B_sE', 'B_E_sE', 'E_B_sB'], 
						    ['A_C_sA', 'C_A_sC', 'A_C_sC', 'C_A_sA'],
						    ['L_N_sL', 'N_L_sN', 'L_N_sN', 'N_L_sL'],
						    ['J_M_sJ', 'M_J_sM', 'J_M_sM', 'M_J_sJ']];

	// Using condition arrays, make a list of the movies to play for this subject
	var movieList = new Array(4);
	for (var iTest=0; iTest<4; iTest++){
		var thisSide = (sides.charAt(iTest) === 'R');
		var thisVers = (versionCondition.charAt(iTest) === '1');
		movieList[iTest] = movieReference[iTest][2 * thisSide + thisVers];
	}
	
	console.log(movieList);
	experiment.movieList = movieList;
	experiment.condition = condition;
	
	// List of videos to play in the single video element for this experiment
	
	var vidElement = buildVideoElement('start', 'vidElement');
	var vidSequence = ['start',
					'attentiongrabber', 
					movieList[0], 
					'attentiongrabber', 
					movieList[1], 
					'attentiongrabber', 
					movieList[2], 
					'attentiongrabber', 
					movieList[3]];
	var lastVid = 0;

	// Sequence of sections of the experiment, corresponding to html sections.
	htmlSequence = [['formBasic', formBasic()],
					['instructions', instructions(experiment.path)],
					['positioning', positioning(experiment.path)],
					['vidElement', vidElement],
					['formPoststudy', formPoststudy()],
					['formDemographic', formDemographic()]];
		
	// Once all the videos are loaded...
	// (currently not used because we're putting all videos in a single container
	// and loading them one by one, rather than putting in separate html5 video 
	// containers and attaching/detaching.  the latter would be better but makes it harder
	// to do fullscreen without asking repeatedly.)
    // jswcam.waitForAssets(function() {

		jswcam.toggleWebCamView(true);
		
		// Immediately remove them from the html canvas
		$('video').detach();

		// Then remove the dialog box blacking out the screen
		bootbox.hideAll();
		addEvent(  {'type': 'endLoading'});
		
		// Start the experiment
		advanceSegment();

    //}, []); // 'vidElement'

	
function advanceSegment(){
	// Detach the current html, if any
	if (currentElement >= 0){
		// Avoid removing data--detach not remove!
		$('#' + htmlSequence[currentElement][0]).detach();
	}
	// Increment the state 
	currentElement++;
	console.log(currentElement);
	// Generate and append next html
	if (currentElement < htmlSequence.length){
		console.log(htmlSequence[currentElement][0]);
		generateHtml(htmlSequence[currentElement][0]);
		return false;
	} else{ // End of experiment -- submit data
		addEvent(  {'type': 'promptUpload'});
		experiment.events = eventArray;
		console.log(experiment);
		jswcam.verifyAndUpload(experiment, jswcam.getExemptIdList());
		addEvent(  {'type': 'endUpload'});
		return false;
	}
}

function generateHtml(segmentName){

	addEvent(  {'type': 'htmlSegmentDisplayed'});

	switch(segmentName){
	
		case "formBasic": // fall through
		case "formPoststudy":
		case "formDemographic":
			$(mainDivSelector).append(htmlSequence[currentElement][1]);
			$("body").removeClass('playingVideo');
			$("html").scrollTop(0);
			$(function() {
				$('#'+segmentName).submit(function(evt) {
					evt.preventDefault();
					console.log(JSON.stringify($('#'+segmentName).serializeObject()));
					console.log(experiment);
					experiment[segmentName] = $('#'+segmentName).serializeObject();
					advanceSegment();
					return false;
				});
			});
			break;
			
		case "positioning":
		case "instructions":
			$(mainDivSelector).append(htmlSequence[currentElement][1]);
			$("body").removeClass('playingVideo');
			$("html").scrollTop(0);
			$(function() {
				$('#' + segmentName + ' :input').click(function(evt) {
					evt.preventDefault();
					advanceSegment();
					return false;
				});
			});
			break;
			
		case "vidElement":
		
			var videoHtml = htmlSequence[currentElement][1];
			var video = videoHtml.contents()[0];
			
		
			function endHandler(event){
				// Important! Otherwise we "stack" advanceSegment() calls
				// when playing the same video more than once.
				addEvent(  {'type': 'endMovie',
							'src': vidSequence[lastVid]});
				this.removeEventListener('ended', endHandler, false);
				
				// At end of each movie (but only then!), click to continue.
				// This handler removes itself (don't do it here)
				video.style.cursor = 'auto'; // show the cursor again
				video.addEventListener("click", clickHandler, false); 
				
				if (!sandbox) {
					jswcam.stopRecording();
				}
				addEvent(  {'type': 'endRecording'});
				return false;
			}
			
			function clickHandler(){
				addEvent(  {'type': 'click',
							'fn': 'advancevideo'});
				video.removeEventListener("click", clickHandler, false);
				if (lastVid == (vidSequence.length - 1)){
					advanceSegment(); // done playing all videos, move on
				} else {
					advanceVideoSource(); // load and play next video
				}
			}
			
			function loadedHandler(){
				video.removeEventListener('canplaythrough', loadedHandler, false);
				if (!sandbox) {
					jswcam.startRecording(true, true);
				}
				addEvent(  {'type': 'startRecording'});
				video.style.cursor = 'none'; // hide the cursor
				video.play();
				addEvent(  {'type': 'startMovie',
							'src': vidSequence[lastVid]});
			}
			
			function advanceVideoSource(){
				lastVid++;
				var videoPlaying = video.currentSrc;
				var ext = videoPlaying.substr(videoPlaying.lastIndexOf("."));
				video.src = experiment.path + "videos/" + ext.substr(1) + "/" + vidSequence[lastVid] + ext;
				video.addEventListener('ended', endHandler);
				video.addEventListener('canplaythrough', loadedHandler, false);
				video.load(); // plays upon loading completely ('canplaythrough' listener)
			}
		
			$(mainDivSelector).append(videoHtml);
			$("body").addClass('playingVideo');
			video.addEventListener('ended', endHandler);

			goFullscreen(video);
			video.addEventListener('canplaythrough', loadedHandler, false);
			video.load();		
				
			break;

	}
}
}	
	
	
function buildVideoElement(videoName, videoID) {

    //Video Tag, no controls specified, autoloading for use
    //with jswcam.waitForAssets function
    var video = $('<video/>', {
	'height': 400,
	'width': 800,
	'preload': 'auto',
	'poster' : experiment.path + "/videos/blackposter.jpg"
    });
	
	// Add video sources
	var sourceList = generateSrcList(videoName, experiment.path);
	
	$.each(sourceList, function(iSrc, sourceStruct) {
		video.append( $('<source/>', sourceStruct) );
		console.log("added new resource", sourceStruct);
		});

    //Fall Through Failure Message
    video.append($('<p/>', {
	'class': 'warning',
	'text' : 'Your browser does not support HTML5.'
    }));
	
	// Don't allow right-clicking on the video to get controls
	video[0].addEventListener('contextmenu', function(evt) {
		console.log(evt);
		evt.preventDefault();
	});
	
	// Make a 'return to full screen' button (will only be visible if the user leaves fs)
	var button = $('<button/>', {
	'id': 'fsbutton', 
	'value': 'Return to full screen', 
	'text': 'Return to full screen'});
	
	button.click(function(evt) {
		addEvent(  {'type': 'click',
					'fn': 'fullscreen'});
		goFullscreen(video[0]);
		return false;
	});

	// stick video and button into one div
	var videoDiv = $('<div/>', {
	'id': videoID});
	videoDiv.append(video);
	videoDiv.append(button);

    return videoDiv;
};
	
}

function generateSrcList(videoName, experimentpath){
   var srcs = [ { type: "video/webm", src: experimentpath + "videos/webm/"+videoName+".webm" },
				{ type: "video/mp4",  src: experimentpath + "videos/mp4/"+videoName+".mp4" },
				{ type: "video/ogg",  src: experimentpath + "videos/ogv/"+videoName+".ogv" }];
   return srcs;
}

function goFullscreen(element){

	addEvent(  {'type': 'goFullscreen'});

	// from http://www.longtailvideo.com/blog/26517/
	//             using-the-browsers-new-html5-fullscreen-capabilities/
	if (element.mozRequestFullScreen && !element.mozFullScreen) { // 
		// This is how to go into fullscren mode in Firefox
		// Note the "moz" prefix, which is short for Mozilla.
		console.log('mozilla fs');
		element.mozRequestFullScreen();
	} else if (element.webkitRequestFullScreen && !element.webkitIsFullScreen) {  // 
		// This is how to go into fullscreen mode in Chrome and Safari
		// Both of those browsers are based on the Webkit project, hence the same prefix.
		element.webkitRequestFullScreen();
	}
}

// Store the html for the initial 'instructions' page (experiment-specific)
function instructions(experimentpath){
	return "  <div id='instructions' class='instructions'>\
  \
  <h1> Talking faces: experiment overview </h1>\
  \
  <p> This experiment will take less than five minutes. You will see eight short movies (about twenty seconds each), alternating between 'Calibration' and 'Story' movies. </p>\
  \
  <h2> Calibration videos </h2>\
  \
  <img height=100px width=400px src='"+experimentpath+"img/calsample.jpg' class='center'/>\
  \
  <p> The 'Calibration' videos look like this.  A colorful shape moves on the left and then on the right of the screen.  We include these so that we know what it looks like when your child is looking to the left or to the right.  This lets us estimate where your child is looking during the 'Story' movies. </p>\
  \
  <p> During 'Calibration' videos, please help us out by directing your child's attention to the moving shape (you can point and look at it with him or her).</p>\
  \
  \
  <h2> Story videos </h2>\
  \
  <img height=100px width=400px src='"+experimentpath+"img/facesample.jpg' class='center'/>\
  \
    <p> The 'Story' videos look like this.  The faces on the left and right are each reading part of a different Dr. Seuss story.  Only the sound from one of the videos is played.  </p>\
	\
	<p> During 'Story' videos, please look at the face you think does NOT match the sound, and do not try to get your child to look at either face (even if he or she looks away from the screen altogether!)  This helps us record your child's judgments, rather than your own.</p>\
	\
  <p> There will be a reminder before each movie about these instructions. </p>\
	\
  <div><input type='button' value='Next: quick setup' id='next'/></div>\
  \
  </div>";
}


// Standard function used in sending experiment object to server
$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};

// Standard function for adding an event to the array.
// Convention: events have at least a 'type' attribute, e.g.
// we could addEvent({'type': 'goFullscreen'})
function addEvent(event) {
	// Add time relative to global time defined initially
	event.time = (new Date()) - tic;
	// Which part of the experiment we're in (which html is displayed)
	if(!htmlSequence || currentElement < 0) {
		event.segment = 'initExperiment';
	} else if(currentElement >= htmlSequence.length){
		event.segment = 'endOfExperiment';
	} else{
		event.segment = htmlSequence[currentElement][0];
	}
	eventArray.push(event);
	console.log(event);
}