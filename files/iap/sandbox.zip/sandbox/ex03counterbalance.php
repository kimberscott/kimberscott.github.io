<?php

/**
 * Parse JSON String into PHP Assoc array,
 * Fetch or create a mongo database for a given
 * experimental id, and record the provided data
 * as a record in the trials collection with primary
 * id based upon the trial subject (user_id).
 */
 
 // TODO: name this something sensible
 
function check_conditions($experiment_id) { //, $user_id, $json
  //$data = json_decode($json, true);

  $m = new Mongo();
  $db = $m->{$experiment_id};

  $collection = $db->trials;
  
  $count_trials = $collection->count();
  
  $condition_counts = array();
  // with a lot of data, what we should really do is loop over trials.
  for ($i = 0; $i < 64; $i++) {
	$condition_counts[$i] = array($collection->count(array('condition' => $i)), $i);
  }

  $small_pair = min($condition_counts); // (#timesSeen, conditionIndex)
  
  return array('condition'=>$small_pair[1]);
}

echo json_encode(check_conditions('speech_match'));

?>