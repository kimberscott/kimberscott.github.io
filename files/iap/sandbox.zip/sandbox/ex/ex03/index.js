if(!$.isFunction(Function.prototype.createDelegate)) {
    Function.prototype.createDelegate = function (scope) {
	var fn = this;
	return function() {
	    fn.apply(scope, arguments);
	};
    }
}

if(!$.isFunction(String.prototype.hashCode)) {
    String.prototype.hashCode = function(){
	var hash = 0;
	if (this.length == 0) return hash;
	for (i = 0; i < this.length; i++) {
	    char = this.charCodeAt(i);
	    hash = ((hash<<5)-hash)+char;
	    hash = hash & hash; // Convert to 32bit integer
	}
	return hash;
    }
}


var consent_link = "/webcam/static/res/child_consent_online.pdf";

(function() {
    $(document).ready(function() {
	page.loadMainApplet();
	//page.loadApplet('#jswcam');

	$('body').bind('showhome', function(evt) {
	    console.log("SHOW HOME");
	    page.buildExperimentGallery('#experiments', experiments);
	});

	page.show("home");

	$('#sidebar_text').html(page.html('sidebar'));
	$(window).resize(function(evt) {
	    console.log("resize");
	    var h = window.innerHeight - $('#jswcam').outerHeight(true);
	    h -= $('#topbar').outerHeight(true) + 25;
	    $('.sidebar_frag').height(h);
	});

	
    });
})();

var page = (function() {
    
    function Library() {
	this.fragments = {};
    }

    default_config = {
	'jq_selector': '#jswcam',

	'app_width' : 200,
	'app_height': 200,

	'basepath'  : '/webcam/',
	'codebase'  : 'java/', //or '/full/path/to/java/'
	'archive'   : 'webcam-0.1.jar',
	
	'libpath'   : 'lib/',
	'uploadpath': 'upload.php',
	
	'rec_width' : 640,
	'rec_height': 480,

	'dll_archive_64'  : 'windows-x86_64.jar',
	'dll_archive_32'  : 'windows-x86_64.jar',
	'so_archive_64'   : 'linux-x86_64.jar',
	'so_archive_32'   : 'linux-x86_64.jar',
	'dylib_archive_64': 'osx-x86_64.jar'
    };

    Library.prototype.init = function(config) {
	this.config = $.extend({}, default_config, config);
    };

    Library.prototype.showConsentDialog = function(callback) {
	var html = this.html('consent');

	var lastId = null;
	bootbox.dialog(html, [{
	    'label': 'Cancel',
	    "class": 'btn-danger',
	    'callback': function() {
		console.log("TODO: I don't Agree / tear down applet");
	    }
	}, {
	    'label': 'Send',
	    "class": "btn-success",
	    'callback': function() {
		if(lastId != null) {
		    document.jswcam.uploadConsent(lastId);
		    jswcam.exemptId(lastId);
		    callback(); //start experiment loading
		    return true; //allow to close
		} else {
		    return false; //don't let the dialog accept if we 
		    //don't have an image for the consent form
		}
	    }
	}, {
	    'label': 'Take a Picture',
	    'class': 'primany',
	    'callback': function() {
		if(lastId != null) {
		    jswcam.exemptId(lastId);
		}
		lastId = document.jswcam.camFrameGrab();
		console.log(document.jswcam);
		jswcam.updateFrame('consent', lastId);
		return false;
	    }
	}
	]);
	jswcam.putFrame('#consent', 'consent', lastId, 320, 240);
    };

    Library.prototype.showVerifyDialog = function(acceptFunc) {
	var html = this.html('upload');
	//TODO: OK -> SEND (confirm -> dialog)
	bootbox.confirm(html, function(result) {
	    if(result) {
		acceptFunc();
	    } else {
		this.show('home');
	    }
	});
    };

    Library.prototype.loadMainApplet = function() {
	if(!this.config) {
	    throw new Exception("Init must be called to load main applet");
	}

	var codebase = this.config['codebase'];
	if(codebase[0] != '/') {
	    codebase = this.config['basepath'] + codebase;
	}

	var applet = this.loadApplet(
	    this.config['jq_selector'], 
	    'jswcam', 
	    this.config['app_width'],
	    this.config['app_height'],
	    'org/mit/webcam/applet/Main',
	    this.config['archive'],
	    codebase, {
		'base_path' : this.config['basepath'],
		'lib_path'  : this.config['libpath'],
		'dll_archive_64' : this.config['dll_archive_64'],
		'dll_archive_32' : this.config['dll_archive_32'],
		'so_archive_64' : this.config['so_archive_64'],
		'so_archive_32' : this.config['so_archive_32'],
		'dylib_archive_64' : this.config['dylib_archive_64'],
		'rec_width' : this.config['rec_width'],
		'rec_height': this.config['rec_height'],
		'upload_path': this.config['uploadpath']
	    }
	);
	    
    };

    Library.prototype.loadApplet = function(selector, name, width, height, entryPoint, archive, codebase, params) {
	var _app = navigator.appName;
	var applet = null;
	
	width = width || 200;
	height = height || 200;
	var cb = this.config['codebase'];
	if(cb[0] != '/') {
	    cb = this.config['basepath'] + cb;
	}
	codebase = codebase || cb;
	entryPoint = entryPoint || 'org/mit/webcam/applet/Main';
	archive = archive || 'webcam-1.0.jar';
	name = name || 'jswcam';
	
	if(_app == 'Netscape') {
	    applet = $('<applet/>', {
		'name' : name,
		'width' : width,
		'height' : height,
		'codebase': codebase,
		'code' : entryPoint,
		'archive' : archive,
		'type' : 'application/x-java-applet'
	    });
	} else if(_app == 'Microsoft Internet Explorer') {
	    applet = $('<applet/>', {
		'name' : name,
		'width': width,
		'height' : height,
		'code' : entryPoint,
		'archive' : archive,
		'codebase' : codebase,
		'type' : 'application/x-java-applet'
	    });
	}

	function param(key, val) {
	    applet.append($('<param/>', {
		'name' : key,
		'value': val
	    }));
	}

	params = params || {};
	console.log('adding params', params);
	for(var key in params) {
	    if(params.hasOwnProperty(key)) {
		console.log('key:', key, 'param:', params[key]);
		param(key, params[key]);
	    }
	}

	if(applet == null) {
	    return false;
	} else {
	    $(selector).append(applet); 
	    return applet;
	}
    };

    Library.prototype.isMenuCollapsed = function() {
	return !$('#menu-container').is(':visible');
    };

    Library.prototype.toggleMenu = function(setVisible) {
	if(typeof setVisible == "undefined") {
	    var setVisible = this.isMenuCollapsed();
	}
	//do not use jquery show(), hide() or reload applet in chrome
	if(setVisible) {
	    $('#menu-container').css('position', '');
	    $('#menu-container').css('right', '');
	    $('#menu').css('position', '');
	    $('#page-container').addClass('skip-fixed-sidebar');
	} else {
	    $('#menu-container').css('position', 'absolute');
	    $('#menu-container').css('right', '-500px');
	    $('#menu').css('position', 'absolute');
	    $('#page-container').removeClass('skip-fixed-sidebar');
	}
    };

    Library.prototype.clear = function(divSel) {
	this._removeTempFiles();
	divSel = divSel || '.content_pane';
	$(divSel).children().remove().end();
    };

    Library.prototype.show = function(key) {

	$('.active').removeClass('active');
	$('.' + key).addClass('active');

	this.clear('.content_pane');
	$('.content_pane').html(this.html(key));

	$('body').trigger('show'+key);
    };
    
    Library.prototype.html = function(key, html) {
	if(!key) {
	    return null;
	}
	if(html) {
	    this.fragments[key] = html;
	}
	return (key in this.fragments) ? this.fragments[key] : null;
    }

    Library.prototype._getTempFiles = function(exp) {
	if($.isArray(exp)) {
	    this.list = exp;
	}
	if(!this.list) {
	    this.list = [];
	}
	return this.list;
    };

    Library.prototype._removeTempFiles = function() {
	var tmp = this._getTempFiles();
	function removeScript(src) {
	    var item = $('script[src="' + src + '"]');
	    if(!item) return false;
	    item.remove();
	}
	function removeCSS(href) {
	    var item = $('link[href="' + href + '"]');
	    if(!item) return false;
	    item.remove();
	}
	
	for(var i in tmp) {
	    if(tmp.hasOwnProperty(i)) {
		var item = tmp[i];
		removeScript(item);
		removeCSS(item);
	    }
	}

	//clear temp files since we just removed them
	this._getTempFiles([]); 
    };

    Library.prototype._replaceExperiment = function(callback, scripts, css) {
	this.clear(); //removes old experiment files too
	
	var num_scripts = 0;
	for(var script in scripts) {
	    if(scripts.hasOwnProperty(script)) {
		num_scripts = num_scripts + 1;
		var src = scripts[script];

		var node = document.createElement('script');
		node.type="text/javascript";
		node.src=src;

		(function(_node) { //todo: IE support if onload is unavailable
		    //ensure listeners are binding 
		    //and unbinding the correct nodes
		    //since js loops don't define a new scope
		    var onloadfn = function(evt) {
			num_scripts = num_scripts - 1;
			//_node.removeEventListener('load', onloadfn);
			_node.onload = null;
			if(num_scripts == 0) callback();
		    }
		    //_node.addEventListener('load', onloadfn);
		    _node.onload = onloadfn;
		})(node);

		document.getElementsByTagName('head')[0].appendChild(node);
	    }
	}
	
	css = css || [];
	for(link in css) {
	    if(css.hasOwnProperty(link)) {
		var src = css[link];
		$('head').append($('<link/>', {
		    'rel': "stylsheet",
		    'type': "text/css",
		    'href' : src
		}));
	    }
	}
	
	
	var arr = [];
	Array.prototype.push.apply(arr, scripts);
	Array.prototype.push.apply(arr, css);
	this._getTempFiles(arr);
    };

    Library.prototype.loadExperiment = function(packaging, divSel) {
	if(!debug) {
	    try {
		document.jswcam.setExperiment(packaging['id']);
		if(typeof userId == 'undefined') userId = 'test_user';
		document.jswcam.setUser(userId);		
	    } catch(e) {
		console.log(e);
	    }
	}

	function loadExp() {
	    var includePath = function(element, index) {
		return packaging['path'] + element;
	    };
	    
	    divSel = divSel || ".content_pane";
	    var scripts = $.map(packaging['scripts'], includePath);
	    var css = [];
	    if('css' in packaging && $.isArray(packaging['css']))
		css = $.map(packaging['css'], includePath);
	    //TODO: path/img
	    var callback = function() {
		//main must be defined in one of
		//the included experiment scripts
		main(divSel, packaging);		 
	    };
	    this._replaceExperiment(callback, scripts, css);
	}
	var delegate = loadExp.createDelegate(this);

	if(!debug) {
	    this.showConsentDialog(delegate);
	} else {
	    delegate();
	}
    };

    Library.prototype.buildExperimentGallery = function(jqSelector, experiments) {
	var columns = 3; //1, 2, 3, 4, 6, 12
	var rows = 3;
	var offset = rows * columns;
	var index = 0;
	
	var next = $('<a/>', {
	    'class': "btn pull-right btn-success",
	    'text' : "Next",
	    'href' : "#"
	});
	var prev = $('<a/>', {
	    'class': "btn pull-left btn-success",
	    'text' : "Prev",
	    'href' : "#"
	});

	var update_display = function() {
	    console.log(index);
	    $(jqSelector).children().remove().end();
	    for(i = 0; i < rows; i++) {
		var arow = $('<div/>', {
		    'class': ["row-fluid"]
		});
		for(j = 0; j < columns; j++) {
		    if(index + i*columns + j >= experiments.length) {
			break; //return;
		    }
		    //var info = experiments[index+(i*columns)+j];
		    (function(info) {
			var exprBlock = $('<div/>', {
			    'class': "span" + 12/columns + " expr_block" 
			});

			var header = $('<h2><a>' + info.name +'</a></h2');
			//header.text(info.name);
			header.click(function() {
			    this.loadExperiment(info, '.content_pane');
			}.createDelegate(this));
			exprBlock.append(header);
			//var desc = $('<p/>');
			//desc.text(info.desc);
			var img = $('<img/>', {
			    'src' : info.img,
			    'alt' : "Could not load image" 
			});
			exprBlock.append(header);
			exprBlock.append(img);
			exprBlock.append(info.desc);
			arow.append(exprBlock);
		    }).createDelegate(this)(experiments[index+(i*columns)+j]);


		}
		$(jqSelector).append(arow);
	    }
	    arow = $('<div/>', {
		'class': ['row-fluid']
	    });
	    var cell = $("<div/>", {
		'class': ['span12']
	    });

	    cell.append(prev);
	    cell.append(next);
	    arow.append(cell);
	    $(jqSelector).append(arow);

	    if(index == 0) {
		prev.addClass("disabled");
	    } else {
		if(prev.hasClass("disabled")) 
		    prev.removeClass("disabled");
		prev.click(function () {
		    index = Math.max(0, index-offset);
		    update_display();
		});
	    }
	    if(index >= experiments.length-offset) {
		next.addClass("disabled");
	    } else {
		if(next.hasClass("disabled")) 
		    next.removeClass("disabled");
		next.click(function() {
		    index = Math.min(index+offset, experiments.length-1);
		    update_display();
		});
	    }
	}.createDelegate(this);
	
	update_display();
    };

    Library.prototype.getUploadingDialog = function(generate) {
	if(!this.uploading) { //undefined -> false
	    this.uploading = false;
	}
	
	if(generate) {
	    this.uploading = true;
	    var uploadingdialog = $('<div/>', {
		'html' : this.html('uploading')
	    });
	    var box = bootbox.dialog('', []);
	    box.children('.modal-body').append(uploadingdialog);
	} else if(typeof generate == "undefined") {
	    return this.uploading;
	} else {
	    this.uploading = false;
	}
	return this.uploading
    };

    Library.prototype.getUploadingMap = function(reset) {
	if(!this.upmap || reset) {
	    this.upmap = {};
	}
	return this.upmap;
    }

    
    Library.prototype._nextBarColor = function() {
	if(!this.currentBarColor) {
	    this.currentBarColor = 0;
	}
	var colors = [
//	    'progress-success',
//	    'progress-warning',
//	    'progress-danger',
	    'progress-info'
	];
	this.currentBarColor = (this.currentBarColor + 1) % colors.length;
	return ' ' + colors[this.currentBarColor];
    };

    Library.prototype.makeProgressBar = function(barId) {
	var outer = $('<div/>', {
	    'class': 'progress' + this._nextBarColor()
	});
	outer.append($('<div/>', {
	    'id': barId.hashCode(),
	    'class': 'bar',
	    'style': 'width: 0%',
	    'text' : barId
	}));
	return outer;
    };

    Library.prototype.updateUpload = function(name, progress, size) {
	console.log(name, progress, size);
	var percentage = (progress / size) * 100;
	var map = this.getUploadingMap();
	if(!(name in map)) {
	    $('.uploading').append(this.makeProgressBar(name));
	} else {
	    $('#' + name.hashCode()).css('width', percentage + '%');
	}
	
	map[name] = {
	    'percentage': percentage,
	    'progress': progress,
	    'size': size
	};
	
	var done = true;
	for(var key in map) {
	    if(map.hasOwnProperty(key)) {
		var prog = map[key];
		done = done && (prog.size == prog.progress);
	    }
	}
	if(done) {
	    setTimeout(function() {
		this.getUploadingMap(true); //reset
		var doneexp = this.getUploadingDialog();
		if(doneexp) {
		    bootbox.hideAll();
		    this.getUploadingDialog(false);
		    this.show('home');
		    jswcam.toggleWebCamView(true);
		}
	    }.createDelegate(this), 1000);
	}
    };

    var _lib = new Library();
    return _lib;
})();

var jswcam = (function() {

    function Library() {}
    Library.prototype.getParameterInfo = function() {
	if(debug) {
	    console.log("getParameterInfo()");
	    return;
	}
	return document.jswcam.getParameterInfo();
    }

    Library.prototype.getExemptIdList = function() {
	if(!this.exemptIds) {
	    this.exemptIds = [];
	}
	return this.exemptIds;
    };

    Library.prototype.exemptId = function(id) {
	if(id == null || id == false) return;
	this.getExemptIdList().push(id);
    };

    /**/
    Library.prototype.startRecording = function(useVideo, useAudio) {
	if(debug) {
	    console.log("startRecording()", arguments);
	    return;
	}

	useVideo = useVideo || false;
	useAudio = useAudio || false;
	if(useVideo && this.rec_width && this.rec_height) {
	    document.jswcam.startRecording(useVideo, useAudio, this.rec_width, this.rec_height);
	} else {
	    document.jswcam.startRecording(useVideo, useAudio);
	}
    };

    /*
     * This function will only take effect the next time startRecording
     * is called. It will specify the width and height in pixels that
     * the webcam should be writing to.
     */
    Library.prototype.setRecordingSize = function(width, height) {
	this.rec_width = width;
	this.rec_height = height;
    };

    Library.prototype.stopRecording = function() {
	if(debug) {
	    console.log("stopRecording()");
	    return {
		'audio' : 'debug',
		'video' : 'debug'
	    };
	}
	var ids = document.jswcam.stopRecording();
	var js_ids = {};
	if(ids[0] != null)
	    js_ids['video'] = ids[0];
	if(ids[1] != null) 
	    js_ids['audio'] = ids[1];
	return js_ids;
    };

    //arguments: (fn, vidId0, vidId1, ..., vidIdN)
    //See http://www.w3.org/TR/html5/the-iframe-element.html#media-elements
    //for more details about html5 video buffering events
    Library.prototype.waitForAssets = function() {
	if(arguments.length == 0) return false;
	
	var callback = arguments[0];
	if(!$.isFunction(callback)) {
	    return false;
	}

	var assets = arguments.length-1;
	for(var i = 1; i < arguments.length; i++) {
	    var id = arguments[i];
	    var tag = document.getElementById(id);

	    //TODO: use jquery for events instead of browser
	    //    : in order to support IE 7, etc
	    
	    //wrapped in closure to preserve the correct tag
	    //for the corrent listener
	    (function(_tag) {
		var _listener = function(evt) {
		    assets = assets - 1;
		    _tag.removeEventListener('canplaythrough', _listener);
		    //ensure we only decrement once per video by removing
		    
		    if(assets == 0) callback();
		};
		_tag.addEventListener('canplaythrough', _listener);
	    })(tag);
	}
    };

    Library.prototype.pageFrameGrab = function() {
	if(debug) {
	    console.log("pageFrameGrab");
	    return "debug";
	}
	return document.jswcam.pageFrameGrab();
    };

    Library.prototype.toggleWebCamView = function(visible) {
	page.toggleMenu(visible);
    };

    Library.prototype.verifyAndUpload = function(json, exemptList) {
	if(debug) {
	    console.log("verifyAndUpload()", json, exemptList);
	    this.show('home');
	    return;
	}

	page.showVerifyDialog(function() {
	    //clear and show uploading dialog
	    page.getUploadingDialog(true);

	    var json_string = JSON.stringify(json);
	    document.jswcam.upload(exemptList);
	    $.ajax({
		'type': 'POST',
		'url': 'mongo.php',
		'data': {
		    'experiment_id' : document.jswcam.getExperiment(),
		    'user_id' : document.jswcam.getUser(),
		    'json_data': json_string
		},
		'success': function(resp) {
		    console.log(resp);
		},
		'failure': function(resp) {
		    console.log(resp);
		}
	    });
	    
	});
    };

    /**
     * Returns a unique id referencing an image taken from
     * the webcam or false, if none was able to be retrieved.
     */
    Library.prototype.camFrameGrab = function() {
	if(debug) {
	    console.log("camFrameGrab");
	    return "debug";
	}
	return document.jswcam.camFrameGrab();
    };

    /**
     * Returns a jquery <img> list for the specified id if valid
     */
    Library.prototype.putFrame = function(selectorId, name, frameId, width, height) {
	if(debug) {
	    console.log('putFrame', arguments);
	    window.name = name;
	    var placeholder = $('<div/', {
		'width': width,
		'height':height,
		'id': frameId
	    });
	    $(selectorId).append(placeholder);
	    return;
	}

	var path = null;
	if(frameId) {
	    path = document.jswcam.getFrame(frameId);
	}
	page.loadApplet(selectorId, name, width, height, 'org/mit/webcam/applet/ImageViewer');
	if(path != null) {
	    setTimeout(function() {
		document[name].setPath(path);
	    }, 500);
	}
    };

    Library.prototype.updateFrame = function(name, frameId) {
	if(debug){
	    console.log("updateFrame()");
	    return;
	}
	if(document[name]) {
	    var path = document.jswcam.getFrame(frameId);
	    document[name].setPath(path);
	}
    };

    Library.prototype.detectMic = function() {
	if(debug) {
	    console.log("detectMic()");
	    return false;
	}
	return document.jswcam.detectMic();
    };

    Library.prototype.detectVideo = function() {
	if(debug) {
	    console.log("detectVideo()");
	    return false;
	}
	return document.jswcam.detectVideo();
    };
    
    return new Library();
})();