function main(mainDivSelector, experiment) {

    $(mainDivSelector).append($('<h1/>', {
	'text' : experiment.name
    }));

	console.log("Starting ", experiment);

	// Make calibration video player
    var video = buildVideoElement('attentiongrabber');
	
    $(mainDivSelector).append(video);

    //or you could make this a progress bar instead, 
    //though that would be much harder to get right
    var box = bootbox.alert(
		"Please wait while the experiment loads.", 
		function(result) {return false;}
    ); //black out the screen until waitforassets returns

    jswcam.waitForAssets(function() {
	box.modal('hide'); //hide the modal dialog 
	//that is blacking out the screen

	//assets are loaded when this callback is executed
	console.log('can play through all videos'); 
	
	// Part 1 of 3: Calibration
	// Show instructions in a brief popup
	
	//add listener for when video finished playing back
	video[0].addEventListener('ended', function(event) {
	    console.log('ended', event);
	    //could have this start a second video on the page

	    //var id = jswcam.stopRecording()
	    jswcam.verifyAndUpload(
		experiment['id'], {
		    'some_data': 'some_other_data',
		    'other_data': 'yipee kai yay'
		}, jswcam.getExemptIdList()
	    );
	});
	
	//do anything else we want with the experiment
	startExperiment(video);
    }, 'vid'); 
}

function startExperiment(video) {
    console.log('starting playback');
    console.log(video);
    video[0].currentTime = 0;
    video[0].play();

    //jswcam.startRecording();
    
}

function buildVideoElement(videoName) {

    //Video Tag, no controls specified, autoloading for use
    //with jswcam.waitForAssets function
    var video = $('<video/>', {
	'id': 'vid',
	'height': 400,
	'width': 800,
	'preload': 'auto',
	'poster' : "http://content.bitsontherun.com/thumbs/q1fx20VZ-720.jpg" 
    });
	
	// Add video sources
	var sourceList = generateSrcList(videoName);
	
	$.each(sourceList, function(iSrc, sourceStruct) {
		video.append( $('<source/>', sourceStruct) );
		console.log("added new resource", sourceStruct);
		});

    //Fall Through Failure Message
    video.append($('<p/>', {
	'class': 'warning',
	'text' : 'Your browser does not support HTML5.'
    }));

    //prevent right click on html5 video so that you cant turn on
    //or access controls from the UI
    video[0].addEventListener('contextmenu', function(evt) {
	console.log(evt);
	evt.preventDefault();
    });

    return video;
};

function generateSrcList(videoName){
   var srcs = [ { type: "video/mp4",  src: "ex/ex03/video/"+videoName+".mp4" },
				{ type: "video/webm", src: "ex/ex03/video/"+videoName+".webm" },
				{ type: "video/ogg",  src: "ex/ex03/video/"+videoName+".ogv" }];
   return srcs;
}