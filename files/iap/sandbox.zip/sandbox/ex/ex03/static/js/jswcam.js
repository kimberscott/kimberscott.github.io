jswcam = (function() {
    function Interface() {}
    
    _lib = new Interface();
    return _lib;
})();