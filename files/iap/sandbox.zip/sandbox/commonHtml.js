
function positioning(experimentpath){
	return "<div id='positioning' class='instructions'>\
  \
  <h1> Getting set up </h1>\
  \
  <h2> Your webcam </h2>\
  \
  <p>We're interested in where your child looks during the movies, so we'll need to be able to see his or her eyes on the webcam video you record.</p>\
  \
  <p>Sit your child on your lap, and adjust your webcam if needed so that the view from your webcam (shown at the right) looks like the center picture below.  Try to get your child's face in the center of the picture, with the whole face visible.  Your own face does not need to be visible.</p>\
  \
  <p>During the movies, please try to keep your child in approximately this same position, in view of the webcam.  (But don't worry: we know kids squirm!)</p>\
  \
  <table style='text-align: center; font-size: smaller'>\
  <tr>\
  <td><img height=100px width=200px src='"+experimentpath+"img/bad2.jpg'/></td>\
  <td><img height=100px width=200px src='"+experimentpath+"img/good.jpg' style='border: thick solid blue'/></td>\
  <td><img height=100px width=200px src='"+experimentpath+"img/bad.jpg'></td>\
  </tr>\
  <tr>\
  <td>Child is off to one side.</td>\
  <td>Great!</td>\
  <td>A bit too close.</td>\
  </tr>\
  </table>\
  \
  <p> (Note: the pictures above are of an ECCL researcher and her son.  Your pictures are kept confidential.) </p>\
\
  <h2> Your speakers </h2>\
  \
  <p> The movies we'll show in a moment include some sound, and it's important that your child is able to hear it.  Please click below to play some music, and adjust your speaker volume so that it's comfortable. </p>\
  \
  <audio controls class='center'>\
	<source src='"+experimentpath+"sounds/testmusic.mp3' type='audio/mpeg'>\
	<source src='"+experimentpath+"sounds/testmusic.ogg' type='audio/ogg'>\
	Your browser does not support this audio format.\
  </audio> \
  <h2> Remove distractions </h2> \
  <p> The movies we show will be full-screen (you may need to click 'allow' when prompted) and it's important that nothing else 'pops up' and distracts your child.  Please exit any programs that might make distracting noises or windows (e.g. an IM client).</p> \
  \
  <p>That's it!  Ready?  Click 'Next' to start the videos.</p>\
  \
  <div><input type='button' value='Next' id='next'/></div></div>";
}

function formBasic(){

formhtml = "  <form id='formBasic'>\
    <fieldset>\
\
	<label for='gender'>Gender</label>\
\
	<label class='radio'>\
		<input type='radio' name='gender' id='f' value='f'>\
		Female\
	</label>\
	\
	<label class='radio'>\
		<input type='radio' name='gender' id='m' value='m'>\
		Male\
	</label>\
\
	<label class='radio'>\
		<input type='radio' name='gender' id='i' value='i'>\
		Intersex\
	</label>\
\
	<label class='radio'>\
		<input type='radio' name='gender' id='na' value='na'>\
		Prefer not to answer\
	</label>\
	\
\
	<p>\
	<label for='birthmonth'>Birthdate</label>	\
	<div class='controls controls-row'>\
	<select id='birthmonth' class='input-medium'>\
		<option>[Month]</option>\
		<option>January</option>\
		<option>February</option>\
		<option>March</option>\
		<option>April</option>\
		<option>May</option>\
		<option>June</option>\
		<option>July</option>\
		<option>August</option>\
		<option>September</option>\
		<option>October</option>\
		<option>November</option>\
		<option>December</option>\
	</select>\
	<input type='number' placeholder='[day]' class='input-small'>\
	<select id='birthyear' class='input-small'>\
		<option>[Year]</option>\
		<option>2012</option>\
		<option>2011</option>\
		<option>2010</option>\
	</select>\
\
	</div>\
	<span class='help-block' class='input-small'>None of this information is used to identify your child. However, if you are uncomfortable providing an exact birthday, you're welcome to \
	give another date within that week.</span>\
\
	<p>\
	<label for='gestage'>Gestational age at birth</label>\
	<select id='gestage'>\
		<option>Full term (36 weeks and up)</option>\
		<option>30 - 36 weeks</option>\
		<option>24 - 30 weeks</option>\
		<option>Under 24 weeks</option>\
		<option>Don't know or prefer not to answer</option>\
	</select>\
	\
	<p>\
	<label for='lastate'>He/she last ate...</label>\
	<select id='lastate'>\
		<option>[how long ago?]</option>\
		<option>Under one hour ago</option>\
		<option>1 - 2 hours ago</option>\
		<option>2 - 4 hours ago</option>\
		<option>Over 4 hours ago</option>\
	</select>\
	\
	<p>\
	<label for='lastwoke'>He/she last woke up...</label>\
	<select id='lastwoke'>\
		<option>[how long ago?]</option>\
		<option>Under one hour ago</option>\
		<option>1 - 2 hours ago</option>\
		<option>2 - 4 hours ago</option>\
		<option>Over 4 hours ago</option>\
	</select>\
	\
	<p>\
	<label for='comments'>Any comments or suggestions?</label>\
	<textarea rows='3' id='comments'></textarea>\
   \
    <input type='submit' value='Submit'/>\
    </fieldset>\
    </form>";
	
	return formhtml;
}

function formPoststudy() {
 return "<form id='formPoststudy'>\
    \
	<h1> A few last questions </h1> \
		\
		<p> These questions are just to help us figure out what setups are best for running online experiments. </p> \
		\
		\
	<p><label for='distance'>During this study, about how far was your child from the computer monitor?</label>\
	<input type='text' name='distance' id='distance' placeholder='e.g. 18 inches'/>\
	<span class='help-inline'>Give your best guess--don't worry about measuring!</span>\
	\
	<p><label for='monitor'>About how wide is your computer monitor?</label>\
	<input type='text' name='monitor' id='monitor' placeholder='e.g. 12 inches'/>\
	\
	<p><label for='comments'>Any comments or suggestions?  (Was anything confusing?  Did the videos run smoothly?)</label>\
	<textarea rows='3' name='comments' id='comments'></textarea>\
	\
	</form>";
}

function formDemographic() {
	formhtml = "<form id='formDemographic'>\
	<p> One reason we are developing Internet-based experiments is to represent\
	a more diverse group of families in our research.  The following questions are all <emph>optional</emph>\
	and will help us better understand what audience we reach with online experiments.  \
	These responses will be used separately from your experiment data (video and previous responses). </p>\
	\
	<p> In these questions, 'your child' refers to the child who just participated in the \
	study. </p>\
\
	<fieldset>\
	<p><label for='language'>What language(s) does your family speak at home?</label>\
	<input type='text' name='language' id='language'/>\
	\
	<p><label for='guardians'>How many parents/guardians does your child live with?</label>\
	<input type='text' name='guardians' id='guardians'/>\
	<span class='help-block'>If the answer varies due to shared custody arrangements or travel, \
	please enter the number of parents/guardians your child is <emph>usually</emph> living with or \
	explain above.\
	</span>\
	\
	<p><label for='race'>What race(s) is your child?</label>\
	<input type='text' name='race' id='race'/>\
\
	<p><label for='childcare'>Who cares for your child while you and/or your partner work? (Check all that apply.) </label>	\
	\
	<table cellpadding='5%'>\
	\
	<tr>\
	<td> <input type='checkbox' name='childcare' value='parent' id='parent'> </td>\
	<td> <label class='checkbox' for='parent'>You, your partner, or another parent/guardian    </label> </td>\
	<tr>\
	\
	<tr >\
	<td> <input type='checkbox' name='childcare' value='daycare' id='daycare'>  </td>\
	<td> <label class='checkbox' for='daycare'>Daycare, family childcare center, or nursery school    </label> </td>\
	<td> <label for='daycarehours'> Hours/week:    </label> </td>\
	<td> <input type='text' class='input-mini' name='daycarehours' id='daycarehours' placeholder='0'/> </td>\
	<tr>\
	\
	<tr>\
	<td> <input type='checkbox' name='childcare' value='nanny' id='nanny'>  </td>\
	<td> <label class='checkbox' for='nanny'>Nanny, other family (e.g. grandparents), babysitter, or tutor    </label> </td>\
	<td> <label for='nannyhours'> Hours/week:    </label> </td>\
	<td> <input type='text' class='input-mini' name='nannyhours' id='nannyhours' placeholder='0'/> </td>\
	<tr>\
	\
	<tr>\
	<td> <input type='checkbox' name='childcare' value='school' id='school'>  </td>\
	<td> <label class='checkbox' for='school'>Elementary school (including after-school programs)    </label> </td>\
	<td> <label for='schoolhours'> Hours/week:    </label> </td>\
	<td> <input type='text' class='input-mini' name='schoolhours' id='schoolhours' placeholder='0'/> </td>\
	<tr>\
	\
	</table>\
\
	<p><label for='siblings'>How many siblings does your child live with?</label>\
	<input type='text' name='siblings' id='siblings'/>\
	\
	<p><label for='siblingages'>If applicable, what are their ages?</label>\
	<input type='text' name='siblingages' id='siblingages'/>\
\
	</fieldset>\
	\
	<fieldset>\
	<p><label for='age'>Your age</label>\
	<select id='age' name='age'>\
		<option>Select...</option>\
		<option>Under 18</option>\
		<option>18-21</option>\
		<option>22-24</option>\
		<option>25-30</option>\
		<option>30-34</option>\
		<option>35-49</option>\
		<option>40-44</option>\
		<option>45-50</option>\
		<option>Over 50</option>\
	</select>\
	\
	<p><label for='gender'>Your gender</label>\
	<select id='gender' name='gender'>\
		<option>Select...</option>\
		<option>Female</option>\
		<option>Male</option>\
		<option>Other</option>\
		<option>Prefer not to answer</option>\
	</select>\
	\
	<p><label for='education-you'>What is the highest level of education you have completed?</label>	\
	<select id='education-you' name='education-you'>\
		<option>Select...</option>\
		<option>Some (or attending) high school</option>\
		<option>High school</option>\
		<option>Some (or attending) college</option>\
		<option>Two-year college degree</option>\
		<option>Four-year college degree</option>\
		<option>Some (or attending) graduate school</option>\
		<option>Graduate degree</option>\
	</select>\
	<p><label for='education-spouse'>What is the highest level of education your spouse or partner has completed, if applicable?</label>	\
	<select id='education-spouse' name='education-spouse'>\
		<option>Select...</option>\
		<option>Not applicable</option>\
		<option>Some (or attending) high school</option>\
		<option>High school</option>\
		<option>Some (or attending) college</option>\
		<option>Two-year college degree</option>\
		<option>Four-year college degree</option>\
		<option>Some (or attending) graduate school</option>\
		<option>Graduate degree</option>\
	</select>\
	\
	<p><label for='interest'>If you had been contacted on the phone by a local university about participating in a study like this, would you have been interested?</label>\
	<select id='interest' name='interest'>\
		<option>Select...</option>\
		<option>Yes</option>\
		<option>No</option>\
		<option>Possibly</option>\
	</select>\
\
	<p><label for='ability'>Would you have been able to schedule an appointment during the workweek to bring your child ~5 miles for this study?</label>\
	<select id='ability' name='ability'>\
		<option>Select...</option>\
		<option>Yes</option>\
		<option>No</option>\
		<option>Possibly</option>\
	</select>\
	\
	<p><label for='comments'>Any additional comments</label>\
	<textarea rows='3' id='comments'></textarea>\
   \
   <br>\
   \
    <input type='submit' value='Submit'/>\
    </fieldset>\
    </form>"
	
	return formhtml;
}