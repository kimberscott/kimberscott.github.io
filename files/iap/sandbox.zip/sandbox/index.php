<?php require_once('php/util.php'); ?>
<!DOCTYPE html>
<html>
  <head>
    <?php
      $title = getenv('WEB_CAM_TITLE');
      printf("<title>%s</title>", $title);
      $description = getenv('WEB_CAM_DESC');
      printf('<meta name="description" content="%s" />', dq_escape($description));
    ?>
    <link rel="stylesheet" type="text/css" href="static/css/styles.css"></link>
    <link rel="stylesheet/less" type="text/css" href="bootstrap/less/bootstrap.less"></link>
    <script src="static/js/less-1.3.0.min.js" type="text/javascript"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script> 
    <script src="static/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="bootbox/bootbox.min.js" type="text/javascript"></script>
    <script src="index.js" type="text/javascript"></script>
    <script type="text/javascript">
      <?php 
	printf("var userId = '%s';", uuid());
	$experiments = load_experiments();
	printf("var experiments = %s;", json_encode($experiments));
	load_fragments(get_default_fragments());

        $conf = array();
        buildConfig($conf, 'jq_selector', '#jswcam');
        buildConfig($conf, 'app_width', 200);
        buildConfig($conf, 'app_height', 200);
        buildConfigEnv($conf, 'basepath', 'BASE_PATH');
        buildConfigEnv($conf, 'codebase', 'CODE_BASE');
        buildConfigEnv($conf, 'libpath', 'LIB_PATH');
        buildConfigEnv($conf, 'archive', 'ARCHIVE');
        buildConfig($conf, 'uploadpath', 'upload.php');
        buildConfigEnv($conf, 'dll_archive_64', 'DLL64');
        buildConfigEnv($conf, 'dll_archive_32', 'DLL32');
        buildConfigEnv($conf, 'so_archive_64', 'SO64');
        buildConfigEnv($conf, 'so_archive_32', 'SO32');
        buildConfigEnv($conf, 'dylib_archive_64', 'DYLIB64');
        printf("page.init(%s);\n", json_encode($conf, true)); 
        printf("var debug = %s;\n", array_key_exists('debug', $_GET) ? "true" : "false");
        ?>
    </script>
  </head>
  
  <body>
    <!-- Top Navbarr -->
    <div id="topbar" class="navbar navbar-fixed-top">
      <div class="navbar-inner">
	<div class="container-fluid">
	  <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	    <span class="icon-bar"></span>
	    <span class="icon-bar"></span>
	    <span class="icon-bar"></span>
	  </a>
	  <a class="brand"><?php echo $title; ?></a>
	  <div class="nav-collapse collapse">
	    <ul class="nav">
	      <li class="home active"><a href="#" onclick="page.show('home')">Home</a></li>
	      <li class="about"><a href="#" onclick="page.show('about')">About</a></li>
	      <li class="contact"><a href="#" onclick="page.show('contact')">Contact</a></li>
	    </ul>
	  </div>
	</div><!--./container-fluid-->
      </div><!--./navbar-inner-->
    </div><!--./navbar-->

    <!--Page Content -->
    <div id="page-container" class="container-fluid skip-fixed-sidebar">
      <div class="row-fluid">
	<div class="span12 content_pane">
	    
	</div>	
      </div><!--/ .row-fluid-->
    </div><!--/ #page-container .container-fluid .skip-fixed-sidebar-->

    
    <!-- Sidebar -->
    <div id="menu-container">
      <div id="menu" class="well sidebar-nav-fixed">
	<!-- INSERT APPLET HERE -->
	<div id="jswcam"></div>
	<div id="sidebar_text"></div>
      </div><!--/ #menu, .well, .sidebar-nav-fixed-->
    </div><!--/ #menu-container-->
  </body>
</html>
